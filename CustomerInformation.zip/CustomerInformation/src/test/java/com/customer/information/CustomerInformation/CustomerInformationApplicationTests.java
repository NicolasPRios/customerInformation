package com.customer.information.CustomerInformation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerInformationApplicationTests {

	@Test
	void contextLoads() {
	}

}
