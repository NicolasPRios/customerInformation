package com.customer.information.CustomerInformation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerInformationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerInformationApplication.class, args);
	}

}
